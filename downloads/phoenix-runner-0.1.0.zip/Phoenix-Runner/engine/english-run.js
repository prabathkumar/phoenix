/**
 * Runs a plain-English test case: each line is a goal the AI works toward on
 * the live screen (web page or mobile app). One runner interface, two
 * adapters - the orchestration below does not know which one it has.
 *
 *   runner.goal(text, {onProgress}) -> {success, reason, actions}
 *   runner.screenshot()             -> {base64, mime} | null
 *   runner.close()                  (optional)
 *
 * Stops at the first failed step (later steps depend on earlier ones) and
 * reports exactly which line failed and why. Secret test-data values never
 * appear in anything emitted (see engine/core/english.js).
 */
const { parseSteps, applyTestData, redact } = require("./core/english");

/** A value kept in .env as "enc:<base64>" is decrypted here, only in memory and only when a step needs it (key: TESTOPS_SECRETS_KEY). Plain values pass through. */
function unlockEnvValue(v) {
  if (!v.startsWith("enc:")) return v;
  let blob; try { blob = JSON.parse(Buffer.from(v.slice(4), "base64").toString("utf8")); } catch { throw new Error("An encrypted value in .env is damaged: run scripts/encrypt-secret.js again for it."); }
  return String(require("./core/testdata-store").decrypt(blob).v ?? "");
}

/**
 * @param {{steps:string, testData?:Object, runner:Object, onEvent?:Function, now?:Function}} opts
 */
async function runEnglish({ steps: stepsText, testData: given = {}, runner, onEvent = () => {}, now = Date.now, env = process.env }) {
  const lines = parseSteps(stepsText);
  const started = now();
  const emit = (e) => { try { onEvent(e); } catch { /* a bad listener must not break the run */ } };
  const results = [];

  // ${NAME} not given in the table falls back to PHOENIX_TEST_<NAME> in the server's environment (.env). Only that prefix: a step can never read an unrelated secret such as a cloud key.
  const testData = { ...given };
  for (const line of lines) for (const m of String(line).matchAll(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g)) {
    const v = env[`PHOENIX_TEST_${m[1]}`];
    if ((testData[m[1]] === undefined || testData[m[1]] === "") && typeof v === "string" && v) {
      try { testData[m[1]] = unlockEnvValue(v); } catch (err) { const out = { status: "failed", reason: err.message, steps: [], durationMs: 0 }; emit({ type: "run-finished", ...out, passed: 0, failed: 0 }); return out; }
    }
  }

  if (!lines.length) {
    const out = { status: "failed", reason: "Write at least one step in English first.", steps: [], durationMs: 0 };
    emit({ type: "run-finished", ...out, passed: 0, failed: 0 });
    return out;
  }

  // Resolve every ${NAME} up front: a missing value should stop the run before anything is clicked.
  const prepared = lines.map((line) => applyTestData(line, testData));
  const missing = [...new Set(prepared.flatMap((p) => p.missing || []))];
  if (missing.length) {
    const out = { status: "failed", reason: `Test data is missing a value for: ${missing.map((m) => "${" + m + "}").join(", ")}.`, steps: [], durationMs: 0 };
    emit({ type: "run-finished", ...out, passed: 0, failed: 0 });
    return out;
  }

  let failed = false;
  for (let i = 0; i < lines.length; i += 1) {
    const shown = lines[i]; // the English as written, with ${NAME} - never the filled-in secret
    if (failed) {
      results.push({ index: i, text: shown, status: "skipped" });
      emit({ type: "step-finished", index: i, text: shown, status: "skipped" });
      continue;
    }
    emit({ type: "step-started", index: i, text: shown });
    let outcome;
    try {
      outcome = await runner.goal(prepared[i].text, {
        onProgress: (p) => emit({ type: "step-progress", index: i, message: redact(p && p.message, testData) }),
      });
    } catch (err) {
      outcome = { success: false, reason: err.message, actions: [] };
    }
    let shot = null;
    try { shot = await runner.screenshot(); } catch { /* a missing screenshot is not a failed step */ }
    const status = outcome.success ? "passed" : "failed";
    const row = {
      index: i,
      text: shown,
      status,
      ...(outcome.success ? {} : { reason: redact(outcome.reason, testData) }),
      actions: (outcome.actions || []).map((a) => redact(a.label || a, testData)),
    };
    results.push(row);
    emit({ type: "step-finished", ...row, ...(shot ? { screenshot: shot.base64, mime: shot.mime } : {}) });
    if (!outcome.success) failed = true;
  }

  const passed = results.filter((r) => r.status === "passed").length;
  const bad = results.filter((r) => r.status === "failed").length;
  const out = { status: bad ? "failed" : "passed", steps: results, passed, failed: bad, durationMs: now() - started };
  emit({ type: "run-finished", ...out });
  return out;
}

/** Screenshots go to the model only when it can read images (a text-only model such as llama3 answers 400 to them). Opt in: TESTOPS_MOBILE_VISION=1 with TESTOPS_MOBILE_OLLAMA_MODEL=llava (or another vision model). */
function visionEnabled(env = process.env) { return /^(1|true|yes)$/i.test(String(env.TESTOPS_MOBILE_VISION || "")) || !!env.TESTOPS_MOBILE_VISION_MODEL; }

function pageMemoryOn(env = process.env) { return !/^(0|false|no|off)$/i.test(String(env.TESTOPS_MOBILE_PAGE_MEMORY || "")); }
function pageMemoryObserve(url, elements) { const pm = require("./core/page-memory"); return pm.describe(pm.observe(url, elements)); }

/** Web: the shared goal loop over a Playwright page. */
function webRunner(page, { runGoalLoop, createPlaywrightSurface, callModel, maxSteps = 8, vision = visionEnabled() } = {}) {
  const loop = runGoalLoop || require("./core/goal-loop").runGoalLoop;
  const mk = createPlaywrightSurface || require("../web/surface/playwright-surface").createPlaywrightSurface;
  return {
    async goal(text, { onProgress } = {}) {
      const pageNotes = [];
      const r = await loop(mk(page), text, { vision, maxSteps, callModel, onProgress, pageNotes, pageMemory: pageMemoryOn() ? pageMemoryObserve : undefined });
      // a failure on a page that is not what it was last run: say what changed
      const why = !r.success && pageNotes.length ? `${r.reason} (${pageNotes[0]})` : r.reason;
      return { success: r.success, reason: why, actions: r.actions };
    },
    async screenshot() {
      return { base64: (await page.screenshot({ type: "jpeg", quality: 50 })).toString("base64"), mime: "image/jpeg" };
    },
  };
}

/** Mobile: the hardware-tested autonomous loop over an Appium driver. */
function mobileRunner(driver, platform, { runAutonomousLoop, maxSteps = 8 } = {}) {
  const loop = runAutonomousLoop || require("./semantic-loop").runAutonomousLoop;
  return {
    async goal(text, { onProgress } = {}) {
      const r = await loop(driver, text, { platform, maxSteps });
      (r.steps || []).forEach((s, n) => onProgress && onProgress({ message: s.instruction, step: n + 1 }));
      const ok = r.stoppedBecause === "goal-achieved";
      return {
        success: ok,
        reason: ok ? "" : `${r.stoppedBecause}${r.reason ? `: ${r.reason}` : ""}`,
        actions: (r.steps || []).map((s) => ({ label: s.instruction })),
      };
    },
    async screenshot() {
      return { base64: await driver.takeScreenshot(), mime: "image/png" };
    },
  };
}

module.exports = { runEnglish, webRunner, mobileRunner };
