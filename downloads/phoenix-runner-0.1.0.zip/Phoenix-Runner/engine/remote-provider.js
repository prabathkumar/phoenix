/**
 * Shared connection-config builder for both platforms' startSession().
 *
 * TestOps ai-automate's engine has always talked to Appium over a plain
 * hostname/port (TESTOPS_MOBILE_APPIUM_HOST/PORT) rather than assuming
 * localhost, so pointing it at a *remote* Appium server was already
 * possible with zero code changes — see session.js's and
 * ios-session.js's original docstrings. What this module adds is the
 * one thing that isn't just "point at a different host": BrowserStack
 * App Automate's specific connection shape (HTTPS, a fixed hub
 * hostname, account auth, and a `bstack:options` capability block
 * instead of bare `appium:*` vendor caps) and its app-reference format
 * (an app already uploaded to BrowserStack, referenced by its `bs://`
 * URL — not a local file path or a bundle id already installed on a
 * Simulator/emulator, since BrowserStack has no concept of either).
 *
 * Why this exists at all: TestOps runs on Linux VMs, and Xcode/the iOS
 * Simulator only run on macOS — Apple's license also prohibits running
 * macOS on non-Apple hardware, so there is no way to stand that up
 * directly on the same Linux VM. BrowserStack App Automate is an
 * already-licensed way to get a real Appium session against real
 * hardware without operating a Mac at all; this module is what lets
 * `TESTOPS_MOBILE_APPIUM_PROVIDER=browserstack` redirect an existing TestOps ai-automate
 * session there instead of a local Appium server, with no changes
 * needed anywhere else in the pipeline (capture/generation/live-view
 * only ever see a normal WebdriverIO `Browser`, regardless of where
 * its session actually runs).
 */

const LOCAL = "local";
const BROWSERSTACK = "browserstack";

function provider(override) {
  // `override` is a per-session choice (the recording or run asked for Local or BrowserStack);
  // without one, the server-wide TESTOPS_MOBILE_APPIUM_PROVIDER decides, exactly as before.
  const value = String(override || process.env.TESTOPS_MOBILE_APPIUM_PROVIDER || LOCAL).toLowerCase();
  if (value !== LOCAL && value !== BROWSERSTACK) {
    throw new Error(
      `Unknown TESTOPS_MOBILE_APPIUM_PROVIDER "${value}" — expected "${LOCAL}" or "${BROWSERSTACK}".`
    );
  }
  return value;
}

/**
 * Connection details (protocol/hostname/port/path) — the same shape
 * for Android and iOS on either provider, since only the capabilities
 * differ by platform.
 */
function buildConnectionConfig(opts = {}) {
  if (provider(opts.provider) === BROWSERSTACK) {
    return {
      protocol: "https",
      hostname: "hub-cloud.browserstack.com",
      port: 443,
      path: "/wd/hub",
    };
  }

  return {
    hostname: process.env.TESTOPS_MOBILE_APPIUM_HOST || "127.0.0.1",
    port: Number(process.env.TESTOPS_MOBILE_APPIUM_PORT) || 4723,
    path: "/",
  };
}

/**
 * Wraps a platform module's base capabilities (platformName,
 * automationName, device selection, and whichever local app-reference
 * capability it built) with whatever the selected provider
 * additionally requires, then applies caller-supplied overrides last
 * so a specific session can still pin something ad hoc on top.
 *
 * On BROWSERSTACK, the local-only app reference (`appium:app` pointing
 * at a file on this machine, or `appium:bundleId` naming something
 * already installed on a local Simulator/emulator) is replaced
 * entirely with TESTOPS_MOBILE_BROWSERSTACK_APP_URL — carrying the local one
 * over alongside it would be actively misleading even though
 * BrowserStack ignores capability keys it doesn't recognize.
 */
function buildCapabilities(baseCapabilities, overrides = {}, opts = {}) {
  if (provider(opts.provider) !== BROWSERSTACK) {
    return { ...baseCapabilities, ...overrides };
  }

  if (!process.env.TESTOPS_MOBILE_BROWSERSTACK_USER || !process.env.TESTOPS_MOBILE_BROWSERSTACK_KEY) {
    throw new Error(
      "TESTOPS_MOBILE_APPIUM_PROVIDER=browserstack requires TESTOPS_MOBILE_BROWSERSTACK_USER and " +
        "TESTOPS_MOBILE_BROWSERSTACK_KEY (an Automate access key from your BrowserStack account " +
        "settings — not your account password)."
    );
  }
  // Normally this comes from TESTOPS_MOBILE_BROWSERSTACK_APP_URL (the env-var-
  // configured flow), but the on-demand upload path (frontend/upload-session.js)
  // already resolved a fresh bs:// URL for *this* session and passes it as
  // an "appium:app" override -- that's just as valid a source, and check
  // for it first so a concurrent request with a different uploaded app
  // never has to touch process.env (which every session shares).
  if (!overrides["appium:app"] && !process.env.TESTOPS_MOBILE_BROWSERSTACK_APP_URL) {
    throw new Error(
      "TESTOPS_MOBILE_APPIUM_PROVIDER=browserstack requires TESTOPS_MOBILE_BROWSERSTACK_APP_URL. " +
        "Upload the app first with `node engine/browserstack-upload.js <path-to-app>` " +
        "and set its bs:// URL here — BrowserStack doesn't accept a local file path or a " +
        "bundle id the way a local Appium server does."
    );
  }

  const { "appium:app": _localApp, "appium:bundleId": _localBundleId, ...platformCapabilities } =
    baseCapabilities;

  return {
    ...platformCapabilities,
    "appium:app": overrides["appium:app"] || process.env.TESTOPS_MOBILE_BROWSERSTACK_APP_URL,
    "bstack:options": {
      userName: process.env.TESTOPS_MOBILE_BROWSERSTACK_USER,
      accessKey: process.env.TESTOPS_MOBILE_BROWSERSTACK_KEY,
      projectName: process.env.TESTOPS_MOBILE_BROWSERSTACK_PROJECT || "TestOps ai-automate",
      buildName: process.env.TESTOPS_MOBILE_BROWSERSTACK_BUILD || "testops-mobile-recording",
      sessionName: process.env.TESTOPS_MOBILE_BROWSERSTACK_SESSION_NAME || "TestOps ai-automate recording session",
      // BrowserStack closes a session after this many idle seconds (default
      // 90, max 300). A tester reading the screen or hunting for the right
      // element easily exceeds 90s -- a real session ended before a tester's
      // first tap ("Session not started or terminated", 2026-10-11).
      idleTimeout: Number(process.env.TESTOPS_MOBILE_BROWSERSTACK_IDLE_TIMEOUT) || 300,
      // Routes this session's device traffic through a BrowserStackLocal
      // tunnel running on TESTOPS_MOBILE_BROWSERSTACK_USER's machine (or wherever
      // it was started), so the app-under-test can reach a backend that
      // isn't reachable from the public internet (e.g. an internal VPN-only
      // API). Requires that tunnel to already be running separately --
      // this flag only tells BrowserStack to use it, it doesn't start one.
      ...(process.env.TESTOPS_MOBILE_BROWSERSTACK_LOCAL === "1" && {
        local: true,
        ...(process.env.TESTOPS_MOBILE_BROWSERSTACK_LOCAL_IDENTIFIER && {
          localIdentifier: process.env.TESTOPS_MOBILE_BROWSERSTACK_LOCAL_IDENTIFIER,
        }),
      }),
    },
    ...overrides,
  };
}

/** What this server can offer a user to choose from (no secrets): used by GET /api/run-options. */
function availability(env = process.env) {
  const bs = Boolean(env.TESTOPS_MOBILE_BROWSERSTACK_USER && env.TESTOPS_MOBILE_BROWSERSTACK_KEY);
  const def = String(env.TESTOPS_MOBILE_APPIUM_PROVIDER || LOCAL).toLowerCase() === BROWSERSTACK ? BROWSERSTACK : LOCAL;
  return { web: { local: true, browserstack: bs }, mobile: { local: true, browserstack: bs, default: def } };
}

module.exports = { availability, LOCAL, BROWSERSTACK, provider, buildConnectionConfig, buildCapabilities };
