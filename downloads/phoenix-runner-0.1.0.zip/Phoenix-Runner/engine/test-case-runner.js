/**
 * Generic, data-driven test-case runner -- the generalization of
 * run-batch-executions.js's original `login-script` mode. That mode
 * proved a real architectural point on real hardware (docs/STATUS.md
 * bugs 18-23): a known, fixed step sequence should never be left to
 * the autonomous loop's per-step model planning, because the model
 * doesn't reliably recognize "this sequence is done, do the next fixed
 * thing" even when every individual step resolves correctly. But that
 * mode's step sequence was still hardcoded JS (`LOGIN_SCRIPT_STEPS` in
 * run-batch-executions.js) -- a new flow meant a new array in a new
 * commit, not something a tester could write themselves.
 *
 * This module is the "test cases in, not hardcoded JS" piece of the
 * "Playwright for mobile, with Appium as the engine" direction: a test
 * case is a plain JSON file (see test-cases/login.json for the first
 * real one, extracted byte-for-byte from the proven LOGIN_SCRIPT_STEPS
 * sequence), and running it still goes through the exact same
 * per-instruction resolver (`executeSemanticAction`) that bugs 12/13/
 * 19/20/21/22/23 already proved correct -- nothing about HOW a single
 * step resolves against a live screen changes here. Only WHERE the
 * step sequence comes from changes: data, not code.
 */

const fs = require("fs");
const { verifyExpectedOutcome, validateExpectShape } = require("../generation/outcome-verification");
const { logExecution } = require("../generation/execution-log");
const { recordResolution } = require("./locator-store");
const { buildTestResult } = require("./test-result");
const { executeApiStep, validateApiStep } = require("./core/api-step");

// Default pause for a "wait" step when the step doesn't specify its own
// durationMs. Exists for a real timing gap found on real hardware
// (docs/STATUS.md, addons.json bug: the post-login-submit notification
// permission dialog appeared at a variable delay across two otherwise
// identical runs -- fast enough for two "tap Allow" steps to catch it
// in one run, and still not up by the time of the following step in
// another). 3s matches the slower observed delay with headroom.
const DEFAULT_WAIT_MS = 3000;

function defaultSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Matches "${ENV_VAR_NAME}" exactly (the whole string, not a
// substring) -- a test case's `text` field is either a literal string
// typed as-is, or a placeholder naming an environment variable to read
// at run time (for credentials/secrets that must never be committed to
// a test-case JSON file in the repo). Partial interpolation (e.g.
// "prefix-${VAR}") is deliberately NOT supported: it would silently
// invite exactly the kind of partial-credential-in-a-committed-file
// mistake this exists to prevent.
const ENV_PLACEHOLDER_RE = /^\$\{([A-Z0-9_]+)\}$/;

/**
 * Loads and validates a test-case JSON file. Each step must have a
 * `kind` ("tap", "type", "scroll", "wait", or "tapIfExists") and an
 * `instruction` (the plain-language text handed to the same resolver
 * `executeSemanticAction` already uses); "type" steps also need a
 * `text` field. `optional: true` marks a step that's allowed to not
 * match anything on screen without failing the whole run (e.g. a
 * system dialog that doesn't always appear -- see
 * test-cases/login.json's first step).
 *
 * An optional `resolvedSelector: {strategy, value}` field is this
 * module's half of the selector-caching/self-healing architecture
 * (docs/STATUS.md): when present, it's a concrete WebDriver selector
 * previously proven correct on real hardware for this exact step, and
 * runScriptSteps() tries it FIRST (no LLM call) before falling back to
 * full semantic resolution -- see executeSemanticAction's
 * `cachedSelector` option in engine/semantic-act-executor.js. A step
 * with no `resolvedSelector` simply always resolves fresh, same as
 * before this field existed.
 *
 * A "tapIfExists" step is different in kind, not degree: it requires a
 * `selector: {strategy, value}` field (NOT resolved/learned -- a
 * literal, hand-authored locator from real evidence) and NEVER goes
 * through the LLM resolver, not even as a fallback. It exists because
 * recovery/conditional steps phrased as plain-language instructions
 * ("tap CLOSE if a dialog is showing") kept getting confidently
 * mis-resolved to an unrelated element on real hardware, across
 * multiple rounds of rewording the instruction and hardening the
 * resolver's prompt (docs/STATUS.md bugs #6/#7/#9/#11/#12/"Thirteenth" --
 * all the same two elements misread as something else). A `tapIfExists`
 * step cannot guess: the exact element either exists (tapped) or
 * doesn't (silently skipped) -- see executeSemanticAction's
 * `exactSelector` option for the implementation.
 *
 * An optional `expect: {appeared?: string[], disappeared?: string[]}`
 * field is the outcome-verification layer (generation/outcome-
 * verification.js): a step can report `success: true` (no WebDriver
 * error, a real element was clicked) while still hitting the WRONG
 * element -- the dominant real-bug class in this file's whole history
 * (docs/STATUS.md bugs #13-#18), invisible from the run summary alone.
 * `expect` lets a test-case author declare what should actually appear
 * or disappear on screen after this step, checked by plain substring
 * matching against the real, already-captured diff -- no model
 * judgment involved, so it can't itself be confidently wrong. A step
 * whose action "succeeds" but whose declared outcome doesn't show up
 * is now reported as a FAILURE, not a false success. See that module's
 * own doc comment for the full rationale and what this does and
 * doesn't close.
 *
 * @param {string} filePath - absolute or relative path to a .json file
 * @returns {Array<{kind: string, instruction: string, text?: string, optional?: boolean, resolvedSelector?: {strategy: string, value: string}, selector?: {strategy: string, value: string}, expect?: {appeared?: string[], disappeared?: string[]}}>}
 */
/** Optional metadata beside the steps ({recordedOn}); an array-form file has none. */
function loadTestCaseMeta(filePath) {
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return parsed && !Array.isArray(parsed) && typeof parsed === "object" ? { recordedOn: parsed.recordedOn } : {};
  } catch { return {}; }
}

function loadTestCaseSteps(filePath) {
  const raw = fs.readFileSync(filePath, "utf8");
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new Error(`test case file "${filePath}" is not valid JSON: ${err.message}`);
  }
  const steps = Array.isArray(parsed) ? parsed : parsed.steps;
  if (!Array.isArray(steps)) {
    throw new Error(`test case file "${filePath}" must be a JSON array of steps, or an object with a "steps" array`);
  }
  const VALID_KINDS = new Set(["tap", "type", "scroll", "wait", "tapIfExists", "api"]);
  steps.forEach((step, i) => {
    if (!step || typeof step !== "object") throw new Error(`test case file "${filePath}": step ${i} is not an object`);
    if (!VALID_KINDS.has(step.kind)) {
      throw new Error(`test case file "${filePath}": step ${i} has invalid "kind" (must be "tap", "type", "scroll", "wait", "tapIfExists", or "api"): ${step.kind}`);
    }
    if (step.kind === "api") {
      const problem = validateApiStep(step);
      if (problem) throw new Error(`test case file "${filePath}": step ${i} ${problem}`);
      return; // an api step is a plain HTTP call: no on-screen instruction needed
    }
    if (typeof step.instruction !== "string" || !step.instruction) {
      throw new Error(`test case file "${filePath}": step ${i} is missing a non-empty "instruction"`);
    }
    if (step.kind === "type" && typeof step.text !== "string") {
      throw new Error(`test case file "${filePath}": step ${i} is a "type" step but has no "text"`);
    }
    if (step.kind === "tapIfExists") {
      const sel = step.selector;
      if (!sel || typeof sel !== "object" || typeof sel.strategy !== "string" || typeof sel.value !== "string") {
        throw new Error(`test case file "${filePath}": step ${i} is a "tapIfExists" step but has no valid "selector" ({strategy, value} strings)`);
      }
    }
    if (step.resolvedSelector !== undefined) {
      const sel = step.resolvedSelector;
      if (!sel || typeof sel !== "object" || typeof sel.strategy !== "string" || typeof sel.value !== "string") {
        throw new Error(`test case file "${filePath}": step ${i} has an invalid "resolvedSelector" (must be {strategy, value} strings)`);
      }
    }
    const expectError = validateExpectShape(step.expect);
    if (expectError) {
      throw new Error(`test case file "${filePath}": step ${i} has an invalid "expect" field: ${expectError}`);
    }
  });
  return steps;
}

/**
 * Resolves a step's `text` field: an "${ENV_VAR}" placeholder is read
 * from process.env at call time (never cached/baked in at load time,
 * so the same loaded steps work across runs with different env), any
 * other string is used literally. Returns undefined for a step with no
 * `text` (a "tap" step). Pure given its env-var input, unit-tested.
 *
 * @param {{kind: string, text?: string}} step
 * @returns {string|undefined}
 */
function resolveStepText(step, vars = {}) {
  if (typeof step.text !== "string") return undefined;
  const match = ENV_PLACEHOLDER_RE.exec(step.text);
  if (!match) return step.text;
  // Test data / values saved by an earlier API step win over the environment.
  if (Object.prototype.hasOwnProperty.call(vars, match[1]) && vars[match[1]] !== undefined) return String(vars[match[1]]);
  const value = process.env[match[1]];
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`test case step references environment variable "${match[1]}", which is not set`);
  }
  return value;
}

/**
 * Lists every "${ENV_VAR}" placeholder referenced anywhere in a loaded
 * test case's steps, without resolving them -- used to give a single
 * clear "these env vars are required" error up front (same UX
 * run-batch-executions.js's original login-specific check already had)
 * instead of failing partway through a run on whichever step happens
 * to need the missing one.
 *
 * @param {Array<{text?: string}>} steps
 * @returns {string[]}
 */
function requiredEnvVars(steps) {
  const names = new Set();
  for (const step of steps) {
    if (typeof step.text !== "string") continue;
    const match = ENV_PLACEHOLDER_RE.exec(step.text);
    if (match) names.add(match[1]);
  }
  return [...names];
}

/**
 * Resolves every step's `text` from process.env up front, returning a
 * new array of steps with literal text only (no more "${VAR}"
 * placeholders) -- see runScriptSteps' own doc comment for exactly why
 * this must happen synchronously, before the caller's first `await`,
 * rather than lazily during the step loop.
 *
 * @param {Array<{kind: string, instruction: string, text?: string, direction?: string, optional?: boolean}>} steps
 * @returns {Array<{kind: string, instruction: string, text?: string, optional?: boolean}>}
 */
function resolveSteps(steps) {
  return steps.map((step) => ({ ...step, text: resolveStepText(step) }));
}

/**
 * Runs a loaded test case's steps, in order, against an already-started
 * driver session -- the same executeSemanticAction() loop
 * run-batch-executions.js's original runOneLoginScriptIteration used
 * inline, now shared by both that mode and the generic `test-case`
 * mode. Stops and reports failure on the first non-optional step that
 * doesn't resolve; an optional step that fails to resolve is skipped,
 * not an error (see loadTestCaseSteps' doc comment).
 *
 * Every step's `text` is resolved from process.env up front, before
 * the first `await` -- not lazily inside the loop. Found necessary
 * from this module's own test suite: `node --test` runs the tests in
 * one file concurrently by default, and several tests here mutate
 * process.env for the duration of one async test function (see
 * test/run-batch-executions.test.js's withEnvAndFreshModule). A step
 * loop that reads process.env again after each `await
 * executeSemanticAction(...)` can resume after a *different*,
 * concurrently-running test has already restored/changed that same
 * env var -- resolving everything synchronously up front (same timing
 * the original hardcoded `text: () => LOGIN_PASSWORD` closures
 * effectively had) avoids that race entirely.
 *
 * A `"wait"` step is a pure timing pause -- no instruction resolution,
 * no device action, and so no call to `executeSemanticAction` at all.
 * It exists for a real race found on real hardware: the post-submit
 * notification-permission dialog appeared at a variable delay across
 * two otherwise-identical runs, fast enough in one for the following
 * "tap Allow" steps to catch it, and still not up by the next step in
 * another -- a step sequence has no way to out-guess that without an
 * explicit pause. `durationMs` defaults to `DEFAULT_WAIT_MS` (3000) if
 * not given. `sleepFn` is injected the same way `executeSemanticAction`
 * is, so tests can run a "wait" step without actually waiting.
 *
 * Each step's optional `resolvedSelector` (see loadTestCaseSteps) is
 * passed through to executeSemanticAction as `cachedSelector`, so a
 * step proven correct on a prior run replays deterministically instead
 * of re-asking the model to guess again from scratch -- the fix for
 * docs/STATUS.md bugs #6/#7/#11/#12 (the same correctly-resolving step
 * independently mis-resolving a different way on a later run). The
 * returned `updatedSteps` is the original `steps` array (same shape,
 * placeholders unresolved) with `resolvedSelector` filled in or updated
 * for every step that successfully resolved -- a fresh resolution
 * (cache miss or no cache yet) records the newly-proven selector, and a
 * cache hit simply confirms the existing one is still correct. The
 * caller is responsible for persisting `updatedSteps` back to the
 * test-case JSON file if it wants that selector reused on the next run;
 * this function never touches the filesystem itself.
 *
 * @param {Object} driver - a started WebdriverIO session
 * @param {Array<{kind: string, instruction: string, text?: string, direction?: string, durationMs?: number, optional?: boolean, resolvedSelector?: {strategy: string, value: string}, selector?: {strategy: string, value: string}}>} steps
 * @param {{platform: string, executeSemanticAction: Function, sleepFn?: Function, testCaseFile?: string, locatorStore?: {db: Object}}} options -
 *   `executeSemanticAction` is injected (not required() here) so
 *   callers/tests can fake it the same way existing tests already do
 *   for run-batch-executions.js. `locatorStore` (engine/locator-store.js's
 *   openLocatorStore() result) is optional -- when omitted, behavior is
 *   identical to before this store existed, nothing is recorded, and
 *   the confidence gate on the JSON pin above still applies regardless
 *   (the two are independent: the gate protects the committed file, the
 *   store is an optional analytics layer on top).
 * @returns {Promise<{success: boolean, detail: string, updatedSteps: Array<Object>}>}
 */
async function runScriptSteps(driver, steps, options) {
  const { platform, executeSemanticAction, sleepFn = defaultSleep } = options;
  // Shared across the run: test data in, values saved by api steps out.
  const vars = { ...(options.testData || {}) };
  // Optional test-data layer (docs/TEST_DATA.md): fills api bodies flagged
  // "generateBody" and refuses to start while a must-exist value is missing.
  // Absent => behaviour is exactly as before.
  const originalSteps = steps;
  // Where this ran / was recorded (informational; never changes how the run behaves).
  const runTarget = require("./core/run-target");
  let ranOn = runTarget.normalizeTarget(options.ranOn);
  if (driver && driver.sessionId) { try { ranOn = runTarget.mergeTarget(ranOn, runTarget.targetFromDriver(driver, platform)); } catch { /* label is best-effort */ } }
  let recordedOn = runTarget.normalizeTarget(options.recordedOn);
  if (!recordedOn && options.testCaseFile) { try { recordedOn = runTarget.normalizeTarget(loadTestCaseMeta(options.testCaseFile).recordedOn); } catch { /* unreadable meta: no label */ } }
  const mismatch = runTarget.compareTargets(recordedOn, ranOn);
  const warnings = mismatch ? [mismatch.message] : [];
  if (options.testDataLayer) {
    const td = require("./core/testdata");
    const prepared = td.prepareApiSteps(steps, { seed: options.testDataLayer.seed || "default" });
    steps = prepared.steps;
    const missing = td.requiredNames(steps, { env: { ...process.env, ...vars } }).filter((n) => prepared.needsYou.includes(n) || td.classify(n).mustExist);
    if (missing.length) {
      return { success: false, detail: `Before this can run I need: ${missing.join(", ")}. These must already exist in your system, so they cannot be made up.`, updatedSteps: originalSteps.map((x) => ({ ...x })), steps: [] };
    }
  }
  // A ${NAME} that an api step saves during the run can't be resolved up
  // front: it is resolved when its own step runs.
  const savedLater = new Set(steps.filter((s) => s.kind === "api").flatMap((s) => Object.keys(s.save || {})));
  const deferred = (step) => {
    const m = typeof step.text === "string" ? ENV_PLACEHOLDER_RE.exec(step.text) : null;
    return Boolean(m && savedLater.has(m[1]));
  };
  const resolvedSteps = steps.map((step) => ({ ...step, text: deferred(step) ? step.text : resolveStepText(step, vars) }));
  // Carry the ORIGINAL (unresolved-text) steps forward for the
  // updatedSteps return value -- we must never write a resolved
  // "${PASSWORD}"-style secret's literal value back out to disk.
  const updatedSteps = originalSteps.map((step) => ({ ...step }));
  let lastResult;
  // Per-step outcomes in the shared pass/fail contract (engine/test-result.js).
  // Additive: `success`/`detail`/`updatedSteps` below are unchanged.
  const stepLog = [];
  const startedAt = Date.now();
  const logStep = (i, step, status, reason) =>
    stepLog.push({ index: i, kind: step.kind, instruction: step.instruction, status, ...(reason ? { reason } : {}) });
  const finish = (success, detail) => ({
    success,
    detail,
    updatedSteps,
    ...(() => {
      const r = buildTestResult({ platform, testCase: options.testCaseFile, steps: stepLog, startedAt, finishedAt: Date.now(), ranOn, recordedOn, warnings });
      return { status: success ? "pass" : "fail", summary: r.summary, steps: r.steps, durationMs: r.durationMs, platform, ...(ranOn ? { ranOn } : {}), ...(recordedOn ? { recordedOn } : {}), ...(warnings.length ? { warnings } : {}) };
    })(),
  });
  for (let i = 0; i < resolvedSteps.length; i += 1) {
    const step = resolvedSteps[i];
    if (step.kind === "api") {
      const r = await executeApiStep(step, { vars, baseUrl: options.apiBaseUrl, fetchFn: options.fetchFn });
      const label = step.instruction || `${step.method || "GET"} ${step.url}`;
      step.instruction = step.instruction || label;
      if (r.ok) { logStep(i, { ...step, instruction: label }, "pass"); continue; }
      logStep(i, { ...step, instruction: label }, "fail", r.reason);
      return finish(false, `api step ${i + 1} "${label}" failed: ${r.reason}`);
    }
    if (step.kind === "wait") {
      await sleepFn(typeof step.durationMs === "number" ? step.durationMs : DEFAULT_WAIT_MS);
      logStep(i, step, "pass");
      continue;
    }
    if (deferred(steps[i])) {
      try { step.text = resolveStepText(steps[i], vars); }
      catch (err) { logStep(i, step, "fail", err.message); return finish(false, `step ${i + 1} "${step.instruction}" failed: ${err.message}`); }
    }
    const result = await executeSemanticAction(driver, step.instruction, {
      kind: step.kind,
      text: step.text,
      platform,
      // Opt-in, off by default -- see semantic-act-executor.js's own doc
      // comment on useVisualGrounding and docs/DEV_ONBOARDING_CHECKLIST.md's
      // Layer 3 section for what this is for and why it's never been
      // wired to anything real until now. A screenshot capture per step
      // has a real cost (extra WebDriver round-trip, extra model-prompt
      // size), so this stays opt-in rather than always-on.
      useVisualGrounding: process.env.TESTOPS_MOBILE_ENABLE_VISUAL_GROUNDING === "1",
      direction: step.direction,
      // "tapIfExists" is given a literal, hand-authored selector and
      // never the AI-learned cache -- see loadTestCaseSteps' doc
      // comment on why these two are deliberately different fields.
      cachedSelector: step.kind === "tapIfExists" ? undefined : step.resolvedSelector,
      exactSelector: step.kind === "tapIfExists" ? step.selector : undefined,
      // Lets executeSemanticAction's outcome-settle retry (engine/
      // semantic-act-executor.js) keep polling past a still-loading
      // screen instead of diffing once, immediately, and handing back a
      // diff that doesn't match `expect` yet purely because the content
      // hadn't finished loading -- see that module's
      // DEFAULT_OUTCOME_SETTLE_TIMEOUT_MS comment. verifyExpectedOutcome
      // below still makes the actual pass/fail call on whatever diff
      // comes back, unchanged.
      expect: step.expect,
    });
    if (!result.success) {
      if (step.optional) { logStep(i, step, "skipped", result.reason); continue; }
      logStep(i, step, "fail", result.reason);
      return finish(false, `step "${step.instruction}" failed: ${result.reason}`);
    }
    // Outcome verification: a step can report success (no WebDriver
    // error) while having hit the wrong element entirely -- this is
    // the check that catches that class instead of trusting the raw
    // success flag. Skipped for a "tapIfExists" step that found
    // nothing to do (result.skipped) -- there's no action outcome to
    // verify when the step correctly did nothing. A step that fails
    // verification is treated exactly like any other failure (honors
    // `optional`, never silently persists a selector that just proved
    // wrong -- see the resolvedSelector-write below, deliberately
    // unreached on this path).
    if (!result.skipped && step.expect) {
      const verification = verifyExpectedOutcome(result.diff, step.expect);
      if (!verification.ok) {
        // Cross-run "wrong but functional click" exclusion (generation/
        // execution-log.js's getExpectFailedSelectors(), the parallel
        // case to the dead-tap exclusion already logged inside
        // executeSemanticAction itself): a tap that produced a REAL,
        // non-empty diff (so it's not a dead tap -- something genuinely
        // happened) but still failed its step's own declared `expect`,
        // even after actAndDiff's outcome-settle retry already gave it
        // a generous window to settle, is logged here -- the one place
        // that both knows `expect` was declared and has already made
        // the final, post-retry verification call. Scoped to a real
        // diff (diffSummary !== "No visible change.") on purpose: a
        // "No visible change." tap is already the OTHER bug class
        // (getDeadSelectors()'s dead-tap exclusion, logged separately
        // inside executeSemanticAction) and must not double-count here
        // as a different failure shape it isn't. Requires a resolved
        // `selector` to log anything useful -- a step with no diff
        // captured at all (checked above implicitly: result.diff is
        // falsy) or no selector (e.g. a scroll) has nothing concrete to
        // record as the wrong candidate.
        if (result.selector && result.diffSummary !== "No visible change.") {
          logExecution({
            instruction: step.instruction,
            kind: step.kind,
            success: true,
            diffSummary: result.diffSummary,
            selector: result.selector,
            expectFailed: true,
            reason: verification.reason,
          });
        }
        if (step.optional) { logStep(i, step, "skipped", verification.reason); continue; }
        logStep(i, step, "fail", verification.reason);
        return finish(false, `step "${step.instruction}" reported success but failed outcome verification: ${verification.reason}`);
      }
    }
    // A "tapIfExists" step's selector is hand-authored evidence, not a
    // learned cache entry -- never let it get overwritten/duplicated
    // into `resolvedSelector` by the generic selector-learning below.
    //
    // Confidence gate (the fix for the real correctness risk flagged in
    // docs/STATUS.md: a self-heal that merely "didn't throw" used to
    // get pinned into the JSON cache unconditionally, so a confidently
    // wrong-but-plausible resolution could silently become the
    // regression baseline every future run trusts with zero further
    // scrutiny). `verified` is real, concrete evidence the resolution
    // did the right thing: the step declared `expect` and it was
    // confirmed (we only reach this line when that passed -- a failed
    // verification already returned above), OR, when no `expect` was
    // declared, a real, non-empty diff was observed (a dead tap -- "No
    // visible change." -- is NOT evidence of correctness, it's the
    // absence of any). A cache HIT (`result.usedCache`) replaying an
    // already-pinned selector is always safe to re-pin as-is: it was
    // already vetted by this same gate when first written, or predates
    // the gate and is already the trusted baseline -- re-pinning it is
    // a no-op, not a new unvetted write.
    const hasExpectEvidence = Boolean(step.expect); // only reached here if it passed
    const hasDiffEvidence = !step.expect && result.diffSummary && result.diffSummary !== "No visible change.";
    const verified = hasExpectEvidence || hasDiffEvidence;
    const isFreshResolution = Boolean(result.selector) && !result.usedCache;

    if (result.selector && step.kind !== "tapIfExists") {
      if (!isFreshResolution || verified) {
        updatedSteps[i] = { ...updatedSteps[i], resolvedSelector: result.selector };
      } else {
        // Deliberately NOT pinned: a fresh resolution with no concrete
        // evidence it hit the right element. Left as-is (no
        // resolvedSelector written for this step this run) so the next
        // run resolves it fresh again -- through the LLM, with its own
        // decline-rather-than-guess contract -- rather than trusting an
        // unverified guess as the new baseline. Logged so this is
        // visible in training-data/executions.jsonl, not a silent gap.
        logExecution({
          instruction: step.instruction,
          kind: step.kind,
          success: true,
          diffSummary: result.diffSummary,
          selector: result.selector,
          unverifiedResolution: true,
          reason: "resolved and acted without a WebDriver error, but no `expect` was declared and no real diff was observed -- not enough evidence to trust as the new pinned selector",
        });
      }
    }
    if (options.locatorStore && result.selector && step.kind !== "tapIfExists") {
      try {
        recordResolution(options.locatorStore, {
          testCaseFile: options.testCaseFile || "(unknown test case)",
          stepIndex: i,
          instruction: step.instruction,
          selector: result.selector,
          verified,
        });
      } catch (err) {
        // The locator store is a confidence/analytics layer, never
        // load-bearing for whether a run succeeds -- a write failure
        // here must never fail or alter the actual test outcome.
      }
    }
    lastResult = result;
    logStep(i, step, result.skipped ? "skipped" : "pass");
  }
  return finish(true, lastResult ? lastResult.diffSummary : "test case completed with no steps run");
}

/**
 * Writes runScriptSteps()'s `updatedSteps` back into a test-case JSON
 * file on disk -- the other half of the read side wired up in
 * loadTestCaseSteps/runScriptSteps above. Preserves the file's original
 * top-level shape (a bare steps array, or an object with a "steps"
 * array plus whatever other keys it had, e.g. a "description"). Only
 * ever writes `resolvedSelector`/other step fields exactly as given in
 * `updatedSteps` -- callers must pass the ORIGINAL (unresolved-text)
 * steps here, never resolveSteps()'s output, or a real credential typed
 * as a literal "${ENV_VAR}" placeholder in the file would get baked in
 * as its resolved secret value on disk.
 *
 * Deliberately synchronous (writeFileSync): this runs once, after a
 * single real-device iteration completes, never in a hot loop or
 * concurrently with another write to the same file, so there's no
 * reason to pay async complexity for it.
 *
 * @param {string} filePath - the same path loadTestCaseSteps() read
 * @param {Array<Object>} updatedSteps - runScriptSteps()'s updatedSteps
 */
function persistResolvedSelectors(filePath, updatedSteps) {
  const raw = fs.readFileSync(filePath, "utf8");
  const parsed = JSON.parse(raw);
  if (Array.isArray(parsed)) {
    fs.writeFileSync(filePath, JSON.stringify(updatedSteps, null, 2) + "\n");
  } else {
    parsed.steps = updatedSteps;
    fs.writeFileSync(filePath, JSON.stringify(parsed, null, 2) + "\n");
  }
}

module.exports = { loadTestCaseMeta,
  loadTestCaseSteps,
  resolveStepText,
  resolveSteps,
  requiredEnvVars,
  runScriptSteps,
  persistResolvedSelectors,
};
