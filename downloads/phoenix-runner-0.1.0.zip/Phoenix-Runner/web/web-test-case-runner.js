/**
 * Web adapter: runs the SAME test-case JSON format the mobile runner
 * uses (engine/test-case-runner.js) in a Playwright page, and reports
 * through the SAME pass/fail contract (engine/test-result.js). One
 * framework, one result shape, three platforms (android | ios | web).
 *
 * Step kinds (superset of mobile; mobile kinds behave the same way):
 *   navigate     {url}                     -- web only; relative URLs join baseUrl
 *   tap          {instruction | selector}  -- click
 *   type         {instruction | selector, text}  -- fill ("${ENV}" placeholders supported)
 *   select       {selector|instruction, option}  -- choose a <select> option by its visible label
 *   press        {key, selector?}          -- keyboard key (e.g. Enter) on the focused field / selector
 *   scroll       {direction?}              -- up|down, default down
 *   wait         {durationMs?}
 *   tapIfExists  {selector}                -- hand-authored locator, never guessed; skipped if absent
 *   assert       {assert: {urlContains?, titleContains?, textVisible?[], textHidden?[]}}
 *                                           -- absolute checks on the page; the web "expected result"
 *
 * Any tap/type step may also carry `expect: {appeared?, disappeared?}`
 * (same field the mobile runner uses): compared against the visible
 * text lines that actually appeared/disappeared as a result of the step.
 *
 * Locator resolution order for tap/type: step.selector (explicit) ->
 * step.resolvedSelector (pinned from an earlier proven run) -> semantic
 * resolution of `instruction` against the page's interactive elements
 * (generation/webview-act.js, same resolver the mobile WebView path
 * uses). A fresh semantic resolution that acted successfully and had
 * evidence (an `expect` that passed, or a visible page change) is
 * returned in `updatedSteps` as the new resolvedSelector, exactly like
 * mobile -- the caller decides whether to persist it.
 *
 * Selector strategies: css | xpath | text | label | testid | role ({role, value=name, exact?}).
 * Any strategy may carry `nth` to pin one match when the locator is not unique.
 */

const path = require("path");
const { buildTestResult } = require("../engine/test-result");
const { executeApiStep, validateApiStep } = require("../engine/core/api-step");
const { interpolate } = require("../engine/core/vars");
const { resolveStepText } = require("../engine/test-case-runner");
const { verifyExpectedOutcome, validateExpectShape } = require("../generation/outcome-verification");
const { SERIALIZE_DOM_SCRIPT } = require("../generation/webview-snapshot");
const { resolveWebviewAction: defaultResolveAction } = require("../generation/webview-act");

const { climbLadder, applyPatches } = require("./web-ladder");
const { createPlaywrightSurface } = require("./surface/playwright-surface");

const WEB_KINDS = new Set(["navigate", "tap", "type", "select", "press", "scroll", "wait", "tapIfExists", "assert", "api"]);
const DEFAULT_WAIT_MS = 1000;
const ACTION_TIMEOUT_MS = 10000;

const VISIBLE_LINES_SCRIPT = function () {
  var text = (document.body && document.body.innerText) || "";
  var seen = {};
  var out = [];
  text.split("\n").forEach(function (l) {
    l = l.trim();
    if (l && !seen[l]) { seen[l] = true; out.push(l.slice(0, 200)); }
  });
  return out.slice(0, 500);
};

/** Validates web steps. Throws on a malformed step (same style as mobile loader). */
function validateWebSteps(steps, label = "test case") {
  if (!Array.isArray(steps)) throw new Error(`${label}: steps must be an array`);
  steps.forEach((step, i) => {
    const where = `${label}: step ${i}`;
    if (!step || typeof step !== "object") throw new Error(`${where} is not an object`);
    if (!WEB_KINDS.has(step.kind)) throw new Error(`${where} has invalid "kind": ${step.kind}`);
    if (step.kind === "api") {
      const problem = validateApiStep(step);
      if (problem) throw new Error(`${where} ${problem}`);
      return;
    }
    if (step.kind === "navigate" && typeof step.url !== "string") throw new Error(`${where} is a "navigate" step with no "url"`);
    if (step.kind === "assert") {
      const a = step.assert;
      if (!a || typeof a !== "object" || !(a.urlContains || a.titleContains || (a.textVisible && a.textVisible.length) || (a.textHidden && a.textHidden.length))) {
        throw new Error(`${where} is an "assert" step with no checks (urlContains/titleContains/textVisible/textHidden)`);
      }
    }
    if (step.kind === "select" && typeof step.option !== "string") throw new Error(`${where} is a "select" step with no "option" (the visible option label)`);
    if (["tap", "type", "select"].includes(step.kind) && !step.instruction && !step.selector && !step.resolvedSelector) {
      throw new Error(`${where} needs an "instruction" or a "selector"`);
    }
    if (step.kind === "press" && typeof step.key !== "string") throw new Error(`${where} is a "press" step with no "key"`);
    if (step.kind === "type" && typeof step.text !== "string") throw new Error(`${where} is a "type" step with no "text"`);
    if (step.kind === "tapIfExists" && !(step.selector && step.selector.strategy && step.selector.value)) {
      throw new Error(`${where} is a "tapIfExists" step with no valid "selector"`);
    }
    const expectError = validateExpectShape(step.expect);
    if (expectError) throw new Error(`${where} has an invalid "expect": ${expectError}`);
  });
  return steps;
}

function locatorFor(page, sel) {
  // `nth` pins one of several matches (recorded when the locator was not unique).
  const pick = (loc) => (Number.isInteger(sel.nth) ? loc.nth(sel.nth) : loc.first());
  switch (sel.strategy) {
    case "css": return Number.isInteger(sel.nth) ? pick(page.locator(sel.value)) : page.locator(sel.value);
    case "xpath": return page.locator(`xpath=${sel.value}`);
    case "text": return pick(page.getByText(sel.value, { exact: false }));
    case "label": return pick(page.getByLabel(sel.value));
    case "testid": return Number.isInteger(sel.nth) ? pick(page.getByTestId(sel.value)) : page.getByTestId(sel.value);
    case "role": return pick(page.getByRole(sel.role, { name: sel.value, exact: sel.exact === true }));
    default: throw new Error(`unsupported web selector strategy "${sel.strategy}"`);
  }
}

async function visibleLines(page) {
  try { return await page.evaluate(VISIBLE_LINES_SCRIPT); } catch { return []; }
}

function diffLines(before, after) {
  const b = new Set(before); const a = new Set(after);
  return {
    appeared: after.filter((l) => !b.has(l)).map((label) => ({ label })),
    disappeared: before.filter((l) => !a.has(l)).map((label) => ({ label })),
  };
}

async function runAssert(page, a) {
  if (a.urlContains && !page.url().includes(a.urlContains)) {
    return `url "${page.url()}" does not contain "${a.urlContains}"`;
  }
  if (a.titleContains && !(await page.title()).includes(a.titleContains)) {
    return `title "${await page.title()}" does not contain "${a.titleContains}"`;
  }
  const lines = (await visibleLines(page)).join("\n").toLowerCase();
  for (const t of a.textVisible || []) {
    if (!lines.includes(t.toLowerCase())) return `expected text not visible: "${t}"`;
  }
  for (const t of a.textHidden || []) {
    if (lines.includes(t.toLowerCase())) return `text expected to be hidden is visible: "${t}"`;
  }
  return null;
}

/**
 * @param {import('playwright').Page} page
 * @param {Array<Object>} steps
 * @param {{baseUrl?: string, testCase?: string, resolveAction?: Function, sleepFn?: Function}} [options]
 * @returns {Promise<Object>} engine/test-result.js shape, plus `updatedSteps`
 */
async function runWebSteps(page, steps, options = {}) {
  const { baseUrl, testCase, resolveAction = defaultResolveAction, sleepFn = (ms) => new Promise((r) => setTimeout(r, ms)) } = options;
  const startedAt = Date.now();
  const vars = { ...(options.testData || {}) };
  const results = [];
  const updatedSteps = steps.map((s) => ({ ...s }));
  let runError;
  // The ladder (Synthetic -> Semantic -> AI -> Guided) is on unless a caller injected
  // its own resolver (tests, legacy callers) or turned it off.
  const ladderOn = options.ladder !== false && !options.resolveAction;
  const surface = ladderOn ? options.surface || createPlaywrightSurface(page) : null;
  const patches = [];
  const pastFailures = [];
  let lastDiff = { appeared: [], disappeared: [] };

  try {
    validateWebSteps(steps, testCase || "web test case");
    // Resolve all ${ENV} text up front (same reason as the mobile runner).
    // Shared across the run: test data in, values saved by api steps out.
    const savedLater = new Set(steps.filter((s) => s.kind === "api").flatMap((s) => Object.keys(s.save || {})));
    const isDeferred = (s) => typeof s.text === "string" && /^\$\{([A-Z0-9_]+)\}$/.test(s.text) && savedLater.has(s.text.slice(2, -1));
    const resolved = steps.map((s) => ({ ...s, text: isDeferred(s) ? s.text : resolveStepText(s, vars) }));

    for (let i = 0; i < resolved.length; i += 1) {
      const step = resolved[i];
      const t0 = Date.now();
      const record = (status, extra = {}) =>
        results.push({ index: i, kind: step.kind, instruction: step.instruction || step.url || step.kind, status, durationMs: Date.now() - t0, ...extra });
      // Fall down the ladder for this step. true = rescued (recorded), false = not rescued.
      const viaLadder = async (failedSelector, reason) => {
        if (!ladderOn || step.kind === "tapIfExists" || !step.instruction) return { rescued: false, reason };
        const r = await climbLadder({
          surface, step, index: i, ctx: { failedSelector, reason, pageDiff: lastDiff, pastFailures },
          options: { ai: options.ai, vision: options.vision, callModel: options.callModel, onGuided: options.onGuided, onProgress: options.onProgress },
        });
        if (r.ok) {
          patches.push(r.patch);
          record("pass", { resolvedBy: r.layer, ...(r.patch.to ? { selector: r.patch.to } : {}), healed: { from: failedSelector, promotable: r.patch.promotable } });
          return { rescued: true };
        }
        if (r.skipped) { record("skipped", { reason: r.reason }); return { rescued: true }; }
        pastFailures.push({ instruction: step.instruction, reason: r.reason || reason });
        return { rescued: false, reason: `${reason}; tried ${r.tried.join(" > ")}: ${r.reason}` };
      };

      try {
        if (step.kind === "api") {
          const r = await executeApiStep(step, { vars, baseUrl: options.apiBaseUrl || baseUrl, fetchFn: options.fetchFn });
          const label = step.instruction || `${step.method || "GET"} ${step.url}`;
          results.push({ index: i, kind: "api", instruction: label, status: r.ok ? "pass" : "fail", durationMs: Date.now() - t0, ...(r.ok ? {} : { reason: r.reason }), api: { status: r.status, saved: Object.keys(r.saved || {}) } });
          if (!r.ok) break;
          continue;
        }
        if (isDeferred(steps[i])) step.text = resolveStepText(steps[i], vars);

        if (step.kind === "wait") { await sleepFn(typeof step.durationMs === "number" ? step.durationMs : DEFAULT_WAIT_MS); record("pass"); continue; }

        if (step.kind === "navigate") {
          const rawUrl = step.url.includes("${") ? interpolate(step.url, { vars }) : step.url;
          const url = baseUrl && !/^[a-z]+:/i.test(rawUrl) ? new URL(rawUrl, baseUrl).toString() : rawUrl;
          await page.goto(url, { waitUntil: "load", timeout: 30000 });
          record("pass");
          continue;
        }

        if (step.kind === "assert") {
          const problem = await runAssert(page, step.assert);
          if (problem) { if (step.optional) { record("skipped", { reason: problem }); continue; } record("fail", { reason: problem }); break; }
          record("pass");
          continue;
        }

        if (step.kind === "press") {
          const beforeLines = step.expect ? await visibleLines(page) : null;
          if (step.selector) await locatorFor(page, step.selector).first().press(step.key, { timeout: ACTION_TIMEOUT_MS });
          else await page.keyboard.press(step.key);
          try { await page.waitForLoadState("load", { timeout: 3000 }); } catch { /* no navigation */ }
          if (step.expect) {
            const v = verifyExpectedOutcome(diffLines(beforeLines, await visibleLines(page)), step.expect);
            if (!v.ok) { record("fail", { reason: v.reason }); break; }
          }
          record("pass");
          continue;
        }

        if (step.kind === "scroll") {
          await page.mouse.wheel(0, step.direction === "up" ? -600 : 600);
          record("pass");
          continue;
        }

        // tap | type | tapIfExists
        let selector = step.kind === "tapIfExists" ? step.selector : step.selector || step.resolvedSelector;
        let usedCache = Boolean(selector) && selector === step.resolvedSelector;
        if (!selector && ladderOn && step.kind !== "tapIfExists") {
          const r = await viaLadder(undefined, "no recorded locator");
          if (r.rescued) continue;
          if (step.optional) { record("skipped", { reason: r.reason }); continue; }
          record("fail", { reason: `could not resolve: ${r.reason}` });
          break;
        }
        if (!selector) {
          const dom = await page.evaluate(SERIALIZE_DOM_SCRIPT);
          const res = await resolveAction(dom, step.instruction, { kind: step.kind === "type" ? "type" : "tap" });
          if (!res.resolved) {
            if (step.optional) { record("skipped", { reason: res.reason }); continue; }
            record("fail", { reason: `could not resolve: ${res.reason}` });
            break;
          }
          selector = res.selector;
        }

        const locator = locatorFor(page, selector);
        if (step.kind === "tapIfExists" && (await locator.count()) === 0) { record("skipped", { reason: "element not present" }); continue; }
        // Pages render after navigation/clicks: give the element time to appear
        // before declaring it missing (an instant count() failed a real run
        // whose next control was still loading).
        let present = (await locator.count()) > 0;
        if (!present && step.kind !== "tapIfExists") {
          try { await locator.first().waitFor({ state: "attached", timeout: ACTION_TIMEOUT_MS }); present = true; } catch { /* still absent */ }
        }
        if (!present) {
          const why = `element not found (${selector.strategy}: ${selector.value})`;
          const r = await viaLadder(selector, why);
          if (r.rescued) continue;
          if (step.optional) { record("skipped", { reason: "element not present" }); continue; }
          record("fail", { selector, reason: r.reason });
          break;
        }

        const before = step.expect ? await visibleLines(page) : null;
        const beforeAny = await visibleLines(page);
        try {
          if (step.kind === "type") await locator.first().fill(step.text, { timeout: ACTION_TIMEOUT_MS });
          else if (step.kind === "select") await locator.first().selectOption({ label: step.option }, { timeout: ACTION_TIMEOUT_MS });
          else await locator.first().click({ timeout: ACTION_TIMEOUT_MS });
        } catch (actErr) {
          // The element exists but cannot be acted on (covered, detached, ...): same ladder.
          const r = await viaLadder(selector, String(actErr.message).split("\n")[0]);
          if (r.rescued) continue;
          throw new Error(r.reason);
        }
        try { await page.waitForLoadState("load", { timeout: 3000 }); } catch { /* no navigation */ }
        const afterAny = await visibleLines(page);
        lastDiff = { appeared: afterAny.filter((l) => !beforeAny.includes(l)), disappeared: beforeAny.filter((l) => !afterAny.includes(l)) };

        if (step.expect) {
          const verification = verifyExpectedOutcome(diffLines(before, afterAny), step.expect);
          if (!verification.ok) {
            if (step.optional) { record("skipped", { selector, reason: verification.reason }); continue; }
            record("fail", { selector, reason: verification.reason });
            break;
          }
        }
        const changed = JSON.stringify(beforeAny) !== JSON.stringify(afterAny);
        if (step.kind !== "tapIfExists" && (usedCache || step.expect || changed || step.kind === "type")) {
          updatedSteps[i] = { ...updatedSteps[i], resolvedSelector: selector };
        }
        record("pass", { selector, resolvedBy: step.kind === "tapIfExists" ? "synthetic" : usedCache ? "synthetic" : step.selector ? "synthetic" : "semantic" });
      } catch (err) {
        if (step.optional) { record("skipped", { reason: err.message }); continue; }
        record("fail", { reason: err.message });
        break;
      }
    }
  } catch (err) {
    runError = err.message;
  }

  const runTarget = require("../engine/core/run-target");
  let ranOn = runTarget.normalizeTarget(options.ranOn);
  try { ranOn = runTarget.mergeTarget(ranOn, runTarget.targetFromBrowser(page.context().browser())); } catch { /* label is best-effort */ }
  const recordedOn = runTarget.normalizeTarget(options.recordedOn);
  const mismatch = runTarget.compareTargets(recordedOn, ranOn);
  const result = buildTestResult({ platform: "web", testCase, steps: results, startedAt, finishedAt: Date.now(), error: runError, ranOn, recordedOn, warnings: mismatch ? [mismatch.message] : [] });
  return { ...result, updatedSteps, patches, healedSteps: applyPatches(steps, patches), resolvedBy: tally(results) };
}

/** How many steps each layer resolved - the headline of a run's health. */
function tally(results) {
  const out = {};
  results.forEach((r) => { if (r.resolvedBy) out[r.resolvedBy] = (out[r.resolvedBy] || 0) + 1; });
  return out;
}

/**
 * Convenience: launch chromium, run, always close. Used by the CLI.
 */
async function runWebTestCase(steps, options = {}) {
  const { chromium } = require("playwright");
  // executablePath: lets a machine with its own Chromium (or a pinned older build)
  // skip `npx playwright install` -- option, or TESTOPS_MOBILE_WEB_CHROMIUM_PATH.
  const { browser } = await require("./browser-provider").launchWebBrowser({
    runOn: options.runOn, headless: options.headless !== false, executablePath: options.executablePath, target: options.ranOn, chromium,
  });
  try {
    const context = await browser.newContext(options.contextOptions || {});
    const page = await context.newPage();
    const ranOn = require("../engine/core/run-target").mergeTarget(require("../engine/core/run-target").normalizeTarget(options.ranOn), require("../engine/core/run-target").targetFromBrowser(browser, { headless: options.headless !== false }));
    return await runWebSteps(page, steps, { ...options, ranOn });
  } finally {
    await browser.close();
  }
}

module.exports = { runWebSteps, runWebTestCase, validateWebSteps, locatorFor, WEB_KINDS };
